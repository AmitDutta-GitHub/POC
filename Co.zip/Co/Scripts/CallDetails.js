﻿function PreAuthSetup() {
    Setup('CallSearch');
}

function PreAuthArchiveSetup() {
    Setup('ArchiveCallSearch');
}

function Setup(controllerName) {
    // we will add more fields as necessary
    $.get('/' + controllerName + '/GetCallDetailsData', function (data) {
        $("#callkey").val(data.CallKey);
    });
}