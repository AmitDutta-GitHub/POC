﻿function PreAuthSetup() {
    Setup('CallSearch');
}

function PreAuthArchiveSetup() {
    Setup('ArchiveCallSearch');
}

function PreAuthSearchCalls() {
    SearchCalls('CallSearch');
}

function PreAuthArchiveSearchCalls() {
    SearchCalls('ArchiveCallSearch');
}

function format(d) {
    //return '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;">' +
    //    '<tr>' +
    //        '<td>ANI:</td>' +
    //        '<td>' + d.SearchIndexResult.ANI + '</td>' +
    //    '</tr>' +
    //    '<tr>' +
    //        '<td>CallStartDate:</td>' +
    //        '<td>' + formatDateForDisplay(d.SearchIndexResult.CallStartDate) + '</td>' +
    //    '</tr>' +
    //    '<tr>' +
    //        '<td>Extension:</td>' +
    //        '<td>' + d.SearchIndexResult.Extension + '</td>' +
    //    '</tr>' +
    //     '<tr>' +
    //        '<td>HealthPlan:</td>' +
    //        '<td>' + d.SearchIndexResult.HealthPlan + '</td>' +
    //    '</tr>' +
    //'</table>';

    var tableString = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" valign="top">' +
            '<thead align="center">' +
            '<tr>' +
                '<th>' +
                    'Agent ID' +
                '</th>' +
                '<th>' +
                    'Image One Login' +
                '</th>' +
                '<th>' +
                    'Start Date' +
                '</th>' +
                '<th colspan="2">' +
                    'Case' +
                '</th>' +
            '</tr>' +
        '</thead>' +
        '<tbody>';

    var tableDataString = '';
    for (var i = 0, len = d.CallSegmentDetailList.length; i < len; i++) {
        tableDataString = tableDataString +
            '<tr>' +
                '<td>' +
                    d.CallSegmentDetailList[i].AgentID +
                '</td>' +
                '<td>' +
                    d.CallSegmentDetailList[i].ImageOneLogin +
                '</td>' +
                '<td>' +
                    d.CallSegmentDetailList[i].TimeStamp +
                '</td>' +
                '<td>' +
                    d.CallSegmentDetailList[i].EpisodeID +
                '</td>' +
                '<td>' +
                    d.CallSegmentDetailList[i].TimeStampEpisodeID +
                '</td>' +
            '</tr>';
    }

    var tableEndString = '</tbody>' +
    '</table>';

    if (d.CallSegmentDetailList.length == 0) {
        return '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" valign="top">' +
                    '<tr>' +
                        '<td>' +
                            'Details not found' +
                        '</td>' +
                    '</tr>' +
                '</table>';
    }

    return tableString + tableDataString + tableEndString;
}

function Setup(controllerName) {
    // display current search criteria values
    $.get('/' + controllerName + '/GetCurrentCriteria', function (data) {
        $("#startdate").val(data.StartDate);
        $("#enddate").val(data.EndDate);
        $("#extension").val(data.Extension);
        $("#healthplan").val(data.HealthPlan);
        $("#ani").val(data.ANI);
        var play = 'Play';
        var download = 'Download';

        // setup the grid
        var table = $('#callgrid').dataTable({
            "ajax": { "url": "/" + controllerName + "/GetCallList", "dataSrc": "" },
            "order": [[2, "desc"]],
            "columns": [
                {
                    "data": "CallKey",
                    "render": function (data, type, row) {
                        return '<a href="/' + controllerName + '/AudioPlayer?callKey=' + data + '" target="_blank">' + play + '</a>';
                    }
                },
                {
                    "data": "CallKey",
                    "render": function (data, type, row) {
                        return '<a href="/CallSearch/DownloadMedia?callKey=' + data + '" target="_blank">' + download + '</a>';
                    }
                },
                {
                    "data": "CallKey",
                    "className": "details-control",
                    "render": function (data, type, row) {
                        return '<div>' + data + '<br/><a>Click for detail</a></div>';
                        //return '<a href="/' + controllerName + '/CallDetails?callKey=' + data + '" target="_blank">' + data + '</a>';
                    }
                },
                {
                    "data": "CallStartDate",
                    "render": function (data, type, row) {
                        return formatDateForDisplay(data);
                    }
                },
                {
                    "data": "CallDuration",
                    "render": function (data, type, row) {
                        return FormatDuration(data);
                    }
                },
                {
                    "data": "Agent"
                },
                    {
                        "data": "Service"
                    },
                    {
                        "data": "Parties"
                    }
            ]
        });

        $('#callgrid tbody').on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.api().row(tr);
            if (row.child.isShown()) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
            }
            else {
                // Open this row
                row.child(format(row.data())).show();
                tr.addClass('shown');
            }
        });
    });
}

function formatDateForDisplay(data) {
    var date = new Date(parseInt(data.substr(6)));
    var month = date.getMonth() + 1;
    var days = date.getDate();
    var hours = date.getHours();
    var mins = date.getMinutes();
    var str = date.getFullYear() + "-" + (month > 9 ? month : "0" + month) + "-" + (days > 9 ? days : "0" + days)
        + " " + (hours > 9 ? hours : "0" + hours) + ":" + (mins > 9 ? mins : "0" + mins);
    return str;
}

/* converts integer into hours:min:sec */
function FormatDuration(data) {
    var millisec = parseInt(data);
    var seconds = (millisec / 1000).toFixed(0);
    var minutes = Math.floor(seconds / 60);
    var hours = "";
    if (minutes > 59) {
        hours = Math.floor(minutes / 60);
        hours = (hours >= 10) ? hours : "0" + hours;
        minutes = minutes - (hours * 60);
        minutes = (minutes >= 10) ? minutes : "0" + minutes;
    }

    seconds = Math.floor(seconds % 60);
    seconds = (seconds >= 10) ? seconds : "0" + seconds;
    if (hours != "") {
        return hours + ":" + minutes + ":" + seconds;
    }
    return minutes + ":" + seconds;
}

function SearchCalls(controllerName) {
    // first get the entered criteria
    var entries = {
        StartDate: $("#startdate").val(),
        EndDate: $("#enddate").val(),
        Extension: $("#extension").val(),
        HealthPlan: $("#healthplan").val(),
        ANI: $("#ani").val(),
    }

    // post those values to the server
    var data = {
        criteria: entries
    };
    $.ajax({
        url: '/' + controllerName + '/SetSearchCriteria',
        data: JSON.stringify(data),
        type: 'POST',
        contentType: 'application/json',
        dataType: 'json'
    })
    .done(function (result) {
        if (result.Outcome == 'success') {
            RefreshTable('#callgrid', '/' + controllerName + '/GetCallList', entries)
        }
    })
}

function RefreshTable(tableId, urlData, searchData) {
    $.getJSON(urlData, searchData, function (json) {

        table = $(tableId).dataTable();
        oSettings = table.fnSettings();
        table.fnClearTable(this);

        if (json != null) {
            for (var i = 0; i < json.length; i++) {
                table.oApi._fnAddData(oSettings, json[i]);
            }
        }

        oSettings.aiDisplay = oSettings.aiDisplayMaster.slice();
        table.fnDraw();
    });
}