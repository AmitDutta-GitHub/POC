﻿using log4net;
using NewCo.Telephony.CallRecording.SearchPlay.Dto;
using NewCo.Telephony.CallRecording.SearchPlay.Facade;
using NewCo.Telephony.CallRecording.SearchPlay.Facade.Interfaces;
using NewCo.Telephony.CallRecording.SearchPlay.Models;
using System;
using System.Collections.Generic;
using System.Web.Hosting;
using System.Web.Mvc;

namespace NewCo.Telephony.CallRecording.SearchPlay.Controllers
{
    public class CallSearchController : Controller
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(CallSearchController));

        ICallRecordingDisplayInfoFacade callRecordingDisplayInfoFacade = new CallRecordingDisplayInfoFacade();
        CommonCode commonCode = new CommonCode();

        public SearchCriteria CurrentCriteria
        {
            get
            {
                if (Session["CurrentCriteria"] == null)
                {
                    return new SearchCriteria();
                }
                else
                {
                    return (SearchCriteria)Session["CurrentCriteria"];
                }
            }
            set
            {
                Session["CurrentCriteria"] = value;
            }
        }

        public ActionResult Index()
        {
            CurrentCriteria = null;
            return View();
        }

        public JsonResult GetCurrentCriteria()
        {
            return Json(CurrentCriteria, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SetSearchCriteria(SearchCriteria criteria)
        {
            ControllerInterface ci = new ControllerInterface()
            {
                Outcome = "success",
                Message = ""
            };

            try
            {
                var start = DateTime.Parse(criteria.StartDate);
                var end = DateTime.Parse(criteria.EndDate);
                CurrentCriteria = criteria;
            }
            catch
            {
                ci.Outcome = "failed";
                ci.Message = "Invalid date values provided.";
            }

            return Json(ci);
        }

        public JsonResult GetCallList()
        {
            var start = DateTime.Parse(CurrentCriteria.StartDate);
            var end = DateTime.Parse(CurrentCriteria.EndDate);

            List<CallRecordingDisplayInfoItem> list = callRecordingDisplayInfoFacade.GetCallRecordingDisplayInfoItemsByCriteria(start, end, CurrentCriteria.Extension, CurrentCriteria.HealthPlan, CurrentCriteria.ANI);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AudioPlayer(string callKey)
        {
            ViewBag.Location = commonCode.GetRecordedCall(callKey);
            ViewBag.CallKey = callKey;
            ViewBag.CallSegmentDetailList = callRecordingDisplayInfoFacade.GetCallSegmentDetailByCallKey(new Guid(callKey));
            return View();
        }

        public ActionResult DownloadMedia(string callKey)
        {
            var location = commonCode.GetRecordedCall(callKey);
            return RedirectToAction("Download", new { fileLocation = location });
        }

        public ActionResult Download(string fileLocation)
        {
            string fullMP4Filepath = (HostingEnvironment.ApplicationPhysicalPath + fileLocation).Replace(@"/", @"\").Trim();
            byte[] fileBytes = System.IO.File.ReadAllBytes(fullMP4Filepath);
            string fileName = (fullMP4Filepath).Replace(HostingEnvironment.ApplicationPhysicalPath + @"Media\", string.Empty).Trim();
            if (System.IO.File.Exists(fullMP4Filepath))
            {
                return File(fileBytes, "video/mp4", fileName);
            }

            return null;
        }
    }
}