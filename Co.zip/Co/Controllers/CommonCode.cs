﻿using NewCo.Telephony.CallRecording.SearchPlay.MediaService;
using System;
using System.Linq;
using System.IO;
using System.Web.Hosting;
using System.Web.Mvc;

namespace NewCo.Telephony.CallRecording.SearchPlay.Controllers
{
    public class CommonCode
    {
        public string GetRecordedCall(string callKey)
        {
            string fullMP4FileFolder = HostingEnvironment.ApplicationPhysicalPath + @"Media";
            string fullMP4Filepath = fullMP4FileFolder + @"\" + callKey + ".mp4";

            Directory.GetFiles(fullMP4FileFolder).Select(f => new FileInfo(f))
            .Where(f => f.LastAccessTime < DateTime.Today.Date.AddDays(0))
            .ToList()
            .ForEach(f => f.Delete());

            if (!File.Exists(fullMP4Filepath))
            {
                try
                {
                    MediaServiceClient mediaService = new MediaServiceClient();
                    using (FileStream fullMP4 = File.Create(fullMP4Filepath))
                    {
                        mediaService.GetMediaStream(Guid.Parse(callKey)).CopyTo(fullMP4);
                    }
                }
                catch (Exception ex)
                {
                    //// Log exception.
                }
            }

            return fullMP4Filepath.Replace(HostingEnvironment.ApplicationPhysicalPath, string.Empty).Replace(@"\", @"/").Trim();
        }
    }
}