﻿using log4net;
using NewCo.Telephony.CallRecording.SearchPlay.Dto;
using NewCo.Telephony.CallRecording.SearchPlay.Facade.Archive;
using NewCo.Telephony.CallRecording.SearchPlay.Facade.Interfaces;
using NewCo.Telephony.CallRecording.SearchPlay.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace NewCo.Telephony.CallRecording.SearchPlay.Controllers
{
    public class ArchiveCallSearchController : Controller
    {
        private static readonly ILog logger = LogManager.GetLogger(typeof(ArchiveCallSearchController));

        ICallRecordingDisplayInfoFacade callRecordingDisplayInfoFacade = new CallRecordingDisplayInfoArchiveFacade();
        CommonCode commonCode = new CommonCode();

        public ArchiveSearchCriteria CurrentCriteria
        {
            get
            {
                if (Session["CurrentCriteria"] == null)
                {
                    return new ArchiveSearchCriteria();
                }
                else
                {
                    return (ArchiveSearchCriteria)Session["CurrentCriteria"];
                }
            }
            set
            {
                Session["CurrentCriteria"] = value;
            }
        }

        public ActionResult Index()
        {
            CurrentCriteria = null;
            return View();
        }

        public JsonResult GetCurrentCriteria()
        {
            return Json(CurrentCriteria, JsonRequestBehavior.AllowGet);
        }

        public JsonResult SetSearchCriteria(ArchiveSearchCriteria criteria)
        {
            ControllerInterface ci = new ControllerInterface()
            {
                Outcome = "success",
                Message = ""
            };

            try
            {
                var start = DateTime.Parse(criteria.StartDate);
                var end = DateTime.Parse(criteria.EndDate);
                CurrentCriteria = criteria;
            }
            catch
            {
                ci.Outcome = "failed";
                ci.Message = "Invalid date values provided.";
            }

            return Json(ci);
        }

        public JsonResult GetCallList()
        {
            var start = DateTime.Parse(CurrentCriteria.StartDate);
            var end = DateTime.Parse(CurrentCriteria.EndDate);

            List<CallRecordingDisplayInfoItem> list = callRecordingDisplayInfoFacade.GetCallRecordingDisplayInfoItemsByCriteria(start, end, CurrentCriteria.Extension, CurrentCriteria.HealthPlan, CurrentCriteria.ANI);
            return Json(list, JsonRequestBehavior.AllowGet);
        }

        public ActionResult AudioPlayer(string callKey)
        {
            ViewBag.Location = commonCode.GetRecordedCall(callKey);
            ViewBag.CallKey = callKey;
            ViewBag.CallSegmentDetailList = callRecordingDisplayInfoFacade.GetCallSegmentDetailByCallKey(new Guid(callKey));
            return View();
        }
    }
}